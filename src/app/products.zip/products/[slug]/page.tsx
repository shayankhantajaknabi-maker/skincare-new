import Link from "next/link";
import { notFound } from "next/navigation";

import { connectToDatabase } from "@/lib/mongodb";
import { Product } from "@/models/Product";
import { formatPrice } from "@/lib/format-price";

import StoreFooter from "../../store-footer";
import StoreHeader from "../../store-header";
import ProductPurchase from "./product-purchase";

export const dynamic = "force-dynamic";

type StoreProduct = {
  _id: unknown;
  name: string;
  slug: string;
  category?: string;
  shortDescription?: string;
  description?: string;
  price: number;
  compareAtPrice?: number | null;
  images?: string[];
  stock: number;
  packType?: "single" | "twin" | "family";
  units?: number;
  badge?: string;
};

export default async function ProductPage({
  params,
}: {
  params: Promise<{
    slug: string;
  }>;
}) {
  const { slug } = await params;

  await connectToDatabase();

  const rawProduct = await Product.findOne({
    slug,
    isActive: true,
  }).lean();

  if (!rawProduct) {
    notFound();
  }

  const product =
    rawProduct as unknown as StoreProduct;

  const rawRelated = await Product.find({
    isActive: true,
    _id: {
      $ne: product._id,
    },
  })
    .sort({
      createdAt: -1,
    })
    .limit(2)
    .lean();

  const relatedProducts =
    rawRelated as unknown as StoreProduct[];

  const image =
    product.images?.[0] || "";

  const oldPrice =
    product.compareAtPrice &&
    product.compareAtPrice > product.price
      ? product.compareAtPrice
      : null;

  const discount =
    oldPrice && oldPrice > 0
      ? Math.round(
          ((oldPrice - product.price) / oldPrice) *
            100
        )
      : null;

  const heroDescription =
    product.shortDescription?.trim() ||
    product.description?.trim() ||
    "";

  const fullDescription =
    product.description?.trim() ||
    product.shortDescription?.trim() ||
    "";

  return (
    <div className="nm-store">
      <StoreHeader />

      <main>
        <section className="bg-white px-4 pb-10 pt-4 sm:px-6 sm:pb-12 sm:pt-5 lg:px-8 lg:pb-12 lg:pt-4">
          <div className="mx-auto max-w-[1160px]">
            <div className="mb-5 flex flex-wrap items-center gap-2 text-[13px] text-[#7a827e] sm:mb-6">
              <Link
                href="/"
                className="transition hover:text-[#005746]"
              >
                Home
              </Link>

              <span className="text-[#bbc0bd]">
                /
              </span>

              <Link
                href="/shop"
                className="transition hover:text-[#005746]"
              >
                Shop
              </Link>

              <span className="text-[#bbc0bd]">
                /
              </span>

              <span className="truncate text-[#315147]">
                {product.name}
              </span>
            </div>

            <div className="grid items-start gap-7 lg:grid-cols-[440px_minmax(0,1fr)] lg:gap-12 xl:grid-cols-[450px_minmax(0,1fr)] xl:gap-14">
              <div className="w-full">
                <div
                  className="
                    relative
                    mx-auto
                    flex
                    h-[360px]
                    w-full
                    max-w-[430px]
                    items-center
                    justify-center
                    overflow-hidden
                    rounded-[24px]
                    border
                    border-[#123529]/[0.07]
                    bg-white
                    px-4
                    py-4
                    shadow-[0_14px_40px_rgba(18,53,41,0.045)]

                    sm:h-[410px]
                    sm:max-w-[440px]
                    sm:px-5
                    sm:py-5

                    lg:mx-0
                    lg:h-[430px]
                    lg:max-w-[440px]

                    xl:h-[440px]
                    xl:max-w-[450px]
                  "
                >
                  {product.badge ? (
                    <span
                      className="
                        absolute
                        left-5
                        top-5
                        z-10
                        rounded-full
                        bg-[#005746]
                        px-3
                        py-1.5
                        text-[9px]
                        font-bold
                        uppercase
                        tracking-[0.08em]
                        text-white
                      "
                    >
                      {product.badge}
                    </span>
                  ) : null}

                  {image ? (
                    <img
                      src={image}
                      alt={product.name}
                      className="
                        block
                        h-auto
                        w-auto
                        object-contain
                        object-center
                        max-h-[365px]
                        max-w-[94%]
                        sm:max-h-[405px]
                        sm:max-w-[92%]
                        lg:max-h-[415px]
                        lg:max-w-[92%]
                        xl:max-h-[425px]
                        xl:max-w-[92%]
                      "
                    />
                  ) : (
                    <div className="flex h-[210px] w-[170px] flex-col items-center justify-center rounded-2xl bg-[#f4f6f4] text-center text-[#123529]">
                      <strong className="text-3xl font-semibold">
                        ON
                      </strong>

                      <span className="mt-2 text-[10px] uppercase tracking-[0.18em]">
                        ORINOCA
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div className="min-w-0 lg:pt-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="h-px w-5 bg-[#d4af37]" />

                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#005746]">
                    ORINOCA NATURAL
                  </p>

                  {product.category ? (
                    <>
                      <span className="text-[#a3aaa6]">
                        ·
                      </span>

                      <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#70827a]">
                        {product.category}
                      </p>
                    </>
                  ) : null}
                </div>

                <h1
                  className="mt-3 text-[38px] leading-none text-[#123529] sm:text-[42px] lg:text-[44px]"
                  style={{
                    fontFamily:
                      "var(--nm-serif)",
                  }}
                >
                  {product.name}
                </h1>

                <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-2">
                  <span
                    className="text-[32px] leading-none text-[#123529] sm:text-[36px]"
                    style={{
                      fontFamily:
                        "var(--nm-serif)",
                    }}
                  >
                    {formatPrice(
                      product.price
                    )}
                  </span>

                  {oldPrice ? (
                    <span className="text-[14px] text-[#999f9b] line-through">
                      {formatPrice(
                        oldPrice
                      )}
                    </span>
                  ) : null}

                  {discount ? (
                    <span className="rounded-full bg-[#edf5f1] px-3 py-1.5 text-[9px] font-semibold text-[#17604d]">
                      Save {discount}%
                    </span>
                  ) : null}
                </div>

                <div className="mt-3 flex items-center gap-2">
                  <span
                    className={`h-2 w-2 rounded-full ${
                      product.stock > 0
                        ? "bg-[#168566]"
                        : "bg-red-500"
                    }`}
                  />

                  <span className="text-[11px] font-medium text-[#68736e]">
                    {product.stock > 0
                      ? `${product.stock} in stock`
                      : "Out of stock"}
                  </span>
                </div>

                {heroDescription ? (
                  <p className="mt-4 max-w-[650px] text-[13.5px] leading-[1.65] text-[#5f6863]">
                    {heroDescription}
                  </p>
                ) : null}

                <div className="mt-5 border-t border-[#e5ebe8] pt-5">
                  <ProductPurchase
                    product={{
                      _id: String(
                        product._id
                      ),
                      name:
                        product.name,
                      slug:
                        product.slug,
                      price:
                        product.price,
                      stock:
                        product.stock,
                      image,
                    }}
                  />
                </div>

                <div className="mt-5 grid gap-3 border-t border-[#e9eeeb] pt-4 sm:grid-cols-3">
                  <div>
                    <p className="text-[10px] font-semibold text-[#123529]">
                      Secure Order
                    </p>
                    <p className="mt-0.5 text-[9px] leading-4 text-[#89918d]">
                      Simple checkout
                    </p>
                  </div>

                  <div>
                    <p className="text-[10px] font-semibold text-[#123529]">
                      Cash on Delivery
                    </p>
                    <p className="mt-0.5 text-[9px] leading-4 text-[#89918d]">
                      Pay on arrival
                    </p>
                  </div>

                  <div>
                    <p className="text-[10px] font-semibold text-[#123529]">
                      Nationwide
                    </p>
                    <p className="mt-0.5 text-[9px] leading-4 text-[#89918d]">
                      Delivery in Pakistan
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-t border-[#edf0ed] bg-[#fafafa] px-4 py-10 sm:px-6 sm:py-12 lg:px-8 lg:py-14">
          <div className="mx-auto max-w-[1160px]">
            <div className="border-b border-[#d8e2dd]">
              <div className="flex gap-6 overflow-x-auto text-sm font-medium text-[#737873] [scrollbar-width:none]">
                <span className="shrink-0 border-b-2 border-[#d4af37] pb-3 text-[#123529]">
                  Description
                </span>
              </div>
            </div>

            {fullDescription ? (
              <div className="max-w-[820px] py-7 text-[14px] leading-7 text-[#5b605d] sm:py-8">
                <p>
                  {fullDescription}
                </p>
              </div>
            ) : null}
          </div>
        </section>

        {relatedProducts.length > 0 ? (
          <section className="bg-white px-4 py-12 sm:px-6 sm:py-14 lg:px-8 lg:py-16">
            <div className="mx-auto max-w-[1160px]">
              <div className="text-center">
                <span className="nm-eyebrow">
                  Complete your ritual
                </span>

                <h2
                  className="mt-3 text-3xl text-[#123529] sm:text-4xl"
                  style={{
                    fontFamily:
                      "var(--nm-serif)",
                  }}
                >
                  You may also like
                </h2>
              </div>

              <div className="mx-auto mt-8 grid max-w-[720px] gap-5 sm:grid-cols-2">
                {relatedProducts.map(
                  (related) => {
                    const relatedImage =
                      related.images?.[0] ||
                      "";

                    return (
                      <article
                        key={String(
                          related._id
                        )}
                        className="overflow-hidden rounded-[20px] border border-[#edf0ed] bg-white transition hover:-translate-y-1 hover:shadow-[0_18px_45px_rgba(18,53,41,0.08)]"
                      >
                        <div className="relative flex h-[225px] items-center justify-center overflow-hidden bg-white p-3">
                          {related.badge ? (
                            <span className="absolute left-4 top-4 z-10 rounded-full bg-[#005746] px-3 py-1.5 text-[8px] font-bold uppercase tracking-[0.08em] text-white">
                              {
                                related.badge
                              }
                            </span>
                          ) : null}

                          {relatedImage ? (
                            <img
                              src={
                                relatedImage
                              }
                              alt={
                                related.name
                              }
                              className="block h-auto w-auto max-h-[210px] max-w-[90%] object-contain object-center"
                            />
                          ) : (
                            <div className="grid h-[150px] w-[130px] place-items-center rounded-xl bg-[#f4f6f4] text-sm font-semibold text-[#123529]">
                              ORINOCA
                            </div>
                          )}
                        </div>

                        <div className="p-5">
                          {related.category ? (
                            <p className="text-[9px] font-semibold uppercase tracking-[0.16em] text-[#769087]">
                              {
                                related.category
                              }
                            </p>
                          ) : null}

                          <h3 className="mt-2 text-lg font-semibold text-[#123529]">
                            {related.name}
                          </h3>

                          {related.shortDescription ? (
                            <p className="mt-2 line-clamp-2 text-[12px] leading-5 text-[#68716b]">
                              {
                                related.shortDescription
                              }
                            </p>
                          ) : null}

                          <p className="mt-3 text-lg font-semibold text-[#005746]">
                            {formatPrice(
                              related.price
                            )}
                          </p>

                          <Link
                            href={`/products/${related.slug}`}
                            className="mt-4 block rounded-full bg-[#005746] px-5 py-2.5 text-center text-xs font-semibold text-white transition hover:bg-[#003f33]"
                          >
                            View Product
                          </Link>
                        </div>
                      </article>
                    );
                  }
                )}
              </div>
            </div>
          </section>
        ) : null}
      </main>

      <StoreFooter
        ctaTitle="Ready to start your skincare ritual?"
        ctaDescription="Explore ORINOCA NATURAL products and find the right addition to your routine."
        ctaButtonText="Shop Now"
        ctaHref="/shop"
      />
    </div>
  );
}